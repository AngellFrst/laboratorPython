import random
import os
import tkinter as tk
from tkinter import filedialog

folder_path = "D:/borisov"

filename1 = "file1.txt"
with open(os.path.join(folder_path, filename1), 'w') as file:
    for _ in range(10):
        number = random.randint(1, 10)
        file.write(f"{number}\n")
print(f"Файл '{filename1}' создан с случайными числами.")

filename2 = "file2.txt"
with open(os.path.join(folder_path, filename2), 'w') as file:
    for _ in range(10):
        number = random.randint(1, 10)
        file.write(f"{number}\n")
print(f"Файл '{filename2}' создан с случайными числами.")

root = tk.Tk()
root.withdraw()
filepath = filedialog.askopenfilename(initialdir=folder_path, title="Выберите файл",
                                      filetypes=(("Text files", "*.txt"), ("All files", "*.*")))
if filepath:
    print(f"Вы выбрали файл: {filepath}")
    with open(filepath, 'r') as file:
        numbers = [int(line.strip()) for line in file]
    print("Содержимое файла:", numbers)
    average = sum(numbers) / len(numbers)
    print(f"Среднее значение чисел: {average}")
else:
    print("Файл не выбран.")

